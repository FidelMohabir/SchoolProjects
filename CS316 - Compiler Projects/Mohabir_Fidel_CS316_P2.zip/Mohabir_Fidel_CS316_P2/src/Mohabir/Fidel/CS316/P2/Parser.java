package Mohabir.Fidel.CS316.P2;
/**

This class is a top-down, recursive-descent parser for the following syntactic categories:

<assignment list> --> <assignment> | <assignment> <assignment list>
<assignment> --> <id> = <E> ";"
<E> --> <term> | <term> + <E> | <term> - <E>
<term> --> <primary> | <primary> * <term> | <primary> / <term>
<primary> --> <id> | <int> | <float> | <floatE> | "(" <E> ")" 

The definitions of the tokens are given in the lexical analyzer class file "LexArithArray.java". 

The following variables/functions of "IO"/"LexArithArray" classes are used:

static void display(String s)
static void displayln(String s)
static void setIO(String inFile, String outFile)
static void closeIO()

static void setLex()
static String t // holds an extracted token
static State state // the current state of the finite automaton
static int getToken() // extracts the next token

An explicit parse tree is constructed in the form of nested class objects.
 
The main function will display the parse tree in linearly indented form.
Each syntactic category name labeling a node is displayed on a separate line, 
prefixed with the integer i representing the node's depth and indented by i blanks. 

**/


public abstract class Parser extends LexAnalyzer
{
	static boolean errorFound = false;
	
	public static FunDefList funDefList() {
			FunDef funDef = FunDef();
			if (state == state.LParen) {
				FunDefList funDefList = funDefList();
				return MultipleFunDef(funDef, funDefL);
			}
			else
				return funDef;
	}
		
	public static FunDef funDef() {
		if (state == state.LParen) {
			getToken();
			if(state == state.Keyword_define) {
				getToken();
				Header header = header();
				getToken();
				Exp exp = exp();
				if (state == state.RParen) {
					return new FunDef();
				}
				else errorMsg(1);
			}
			else 
				errorMsg(6);
		}
		else
			errorMsg(1);
		return null;
	}
	
	
	public static Header header() {
		if (state == state.LParen) {
			getToken();
			FunName funName = FunName();
			getToken();
			ParameterList parameterList = parameterList();
			getToken();
			if (state == state.RParen) {
				return new Header();
			}
			else errorMsg(1);
		}
		else errorMsg(1);
	}
	
	public static FunName funName() {
		if (state==state.Id) {
			Id id = new Id(t);
			return id;
		}
		else
			errorMsg(5);
		return null;
	}
	
	public static ParameterList parameterList() {
		if (t != "") {
			if (state == state.Id) {
				Id ident = new Id(t);
			}
			else
				errorMsg(5);
			getToken();
			ParameterList parameterList = ParameterList();
			return NonEmptyParameterList(ident, parameterList);
			
		}
		else
			return new ParameterList();
			
	}
	
	public static Exp exp() {
		if (state==state.Id || state==state.Int || state==state.Float || state==state.FloatE || state==state.False || state==state.True) {
			Atom atom = atom();
		}
		else if (state==state.Quote) {
			getToken();
			sExp sExp = sExp();
		}
		else if (state==state.LParen) {
			ListExp listExp = listExp();
		}
		else errorMsg(1);
	}
	
	public static Atom atom() {
		switch (state) 
		{
		case Id:
			Id id= new Id(t);
			getToken();
			return id;
		
		case Int:
			Int intElem = new Int(Integer.parseInt(t));
			getToken();
			return intElem;
		
		case Float: case FloatE:
			Floatp floatElem = new Floatp(Float.parseFloat(t));
			getToken();
			return floatElem;
			
		case False: case True:
			TF tf = new TF(t);
			getToken();
			return tf;
			
		default:
			
			errorMsg(2);
			return null;
		}
	}
	
	public static SExp sExp() {
		if (state==state.Id || state==state.Int || state==state.Float || state==state.FloatE || state==state.False || state==state.True) {
			AtomicSExp atomicSExp = atomicSExp();
		}
		else if (state==state.LParen) {
			getToken();
			if (state==state.Id || state==state.Int || state==state.Float || state==state.FloatE || state==state.False || state==state.True) {
				SExp atomicSExp = SExp();
				getToken();
				if (state==state.Period) {
					getToken();
					if (state==state.Id || state==state.Int || state==state.Float || state==state.FloatE || state==state.False || state==state.True) {
						SExp sExp = SExp();
					}
					else
						errorMsg(1);
				}
				else 
					errorMsg(7);
			}
			else 
				errorMsg(2);
		}
		else
			errorMsg(1);
	}
	
	public static AtomicSExp atomicSExp() {
		if (state==state.Id || state==state.Int || state==state.Float || state==state.FloatE || state==state.False || state==state.True) {
			AtomicSExp atomicSExp = atomicSExp();
		}
		else errorMsg(2);
	}
	
	public static ListExp listExp() {
		if (state == state.LParen) {
			getToken();
			ListExpInside listExpInside = listExpInside();
			if (state == state.RParen) {
				getToken();
				return new ListExp(ListExpInside);
			}
			else
				errorMsg(1);
		}
		else 
			errorMsg(1);
	}
	
	public static ListExpInside listExpInside() {
		if (state==state.Keyword_if) {
			If ifs = ifs();
		}
		else if (state==state.Keyword_cond) {
			Cond cond = cond();
		}
		else if (state==state.keywor_id) {
			FunCall funcall = funcall();
		}
		else if (state==state.Add || state==State.Sub || state==state.Div || state==state.Lt || state==state.Le || 
				state==state.Gt || state==state.Ge || state==state.Keyword_and || state==state.Keyword_or || 
				state==state.Keyword_not || state==state.Keyword_equal || state==state.Keyword_car ||
				state==state.Keyword_cdr || state==state.Keyword_cons) {
			OperatorExp operatorExp = OperatorExp();
		}
		else 
			errorMsg(6);
	}
	
	public static If ifs() {
		if (state == state.Keyword_if) {
			getToken();
			Exp exp = exp();
			getToken();
			Exp expp = exp();
			getToken();
			Exp exppp = exp();
			getToken();
		}
		else
			errorMsg(6);
	}
	
	public static Cond cond() {
		if (state == state.Keyword_cond) {
			getToken();
			CaseList caseList = caseList();
		}
		else 
			errorMsg(6);
	}
	
	public static CaseList caseList() {
		CaseExp caseExp = caseExp();
		if (state == state.LParen) {
			CaseList caseList = caseList();
			return new MultipleCaseList(caseExp, caseList);
		}
		else
			return new caseExp();
	}
	
	public static CaseExp caseExp() {
		if (state == state.LParen) {
			getToken();
			if (state==state.Id || state==state.Int || state==state.Float || state==state.FloatE || state==state.False || state==state.True || 
					state==state.Quote || state==state.Keyword_if || state==state.Keyword_cond || state==state.Add || state==State.Sub || state==state.Div || state==state.Lt || state==state.Le || 
					state==state.Gt || state==state.Ge || state==state.Keyword_and || state==state.Keyword_or || 
					state==state.Keyword_not || state==state.Keyword_equal || state==state.Keyword_car ||
					state==state.Keyword_cdr || state==state.Keyword_cons) {
				Case case = case();
			}
			else if (state==state.Keyword_else) {
				ElseCase elseCase = elseCase();
			}
			else
				errorMsg(8);
		}
		else
			errorMsg(1);
	}
	
	public static Case case() {
		if (state==state.Id || state==state.Int || state==state.Float || state==state.FloatE || state==state.False || state==state.True || 
					state==state.Quote || state==state.Keyword_if || state==state.Keyword_cond || state==state.Add || state==State.Sub || state==state.Div || state==state.Lt || state==state.Le || 
					state==state.Gt || state==state.Ge || state==state.Keyword_and || state==state.Keyword_or || 
					state==state.Keyword_not || state==state.Keyword_equal || state==state.Keyword_car ||
					state==state.Keyword_cdr || state==state.Keyword_cons) {
			Exp Exp = Exp();
			getToken();
			if (state==state.Id || state==state.Int || state==state.Float || state==state.FloatE || state==state.False || state==state.True || 
					state==state.Quote || state==state.Keyword_if || state==state.Keyword_cond || state==state.Add || state==State.Sub || state==state.Div || state==state.Lt || state==state.Le || 
					state==state.Gt || state==state.Ge || state==state.Keyword_and || state==state.Keyword_or || 
					state==state.Keyword_not || state==state.Keyword_equal || state==state.Keyword_car ||
					state==state.Keyword_cdr || state==state.Keyword_cons) {
				Exp Exp = Exp();
			}
			else
				errorMsg(8);
		}
		else errorMsg(8);
	}

	
	public static ElseCase elseCase() {
		if (state==state.Keyword_else) {
			getToken();
			Exp exp = exp();
		}
		else 
			errorMsg(6);
	}
	
	public static FunCall funcall() {
		if (state==state.Id) {
			FunName funName = funName();
			getToken();
			if (state==State.LParen) {
				ListExp listExp = listExp();
			}
			else
				errorMsg(1);
		}
		else
			errorMsg(5);
	}
	
	public static OperatorExp operatorExp() {
		if (state==state.Id || state==state.Int || state==state.Float || state==state.FloatE || state==state.False || state==state.True || 
				state==state.Quote || state==state.Keyword_if || state==state.Keyword_cond || state==state.Add || state==State.Sub || state==state.Div || state==state.Lt || state==state.Le || 
				state==state.Gt || state==state.Ge || state==state.Keyword_and || state==state.Keyword_or || 
				state==state.Keyword_not || state==state.Keyword_equal || state==state.Keyword_car ||
				state==state.Keyword_cdr || state==state.Keyword_cons) {
			Operator operator = operator();
			getToken();
			if (t == "" || state==state.Id || state==state.Int || state==state.Float || state==state.FloatE || state==state.False || state==state.True || state==state.Quote || state==state.LParen ) {
				ListExp listExp = listExp();
			}
			else
				errorMsg(5);
		}
		else
			errorMsg(8);
	}
	
	public static Operator operator() {
		if (state==state.Add || state==State.Sub || state==state.Div || state==state.Lt || state==state.Le || 
				state==state.Gt || state==state.Ge || state==state.Keyword_and || state==state.Keyword_or || 
				state==state.Keyword_not || state==state.Keyword_equal || state==state.Keyword_car ||
				state==state.Keyword_cdr || state==state.Keyword_cons) {
			String id = t;
			return id;
		}
		else {
			ErrorMsg(6);
			return null;
		}
	}
	
	public static ExpList expList() {
		if (t!="") {
			if (state==state.Id || state==state.Int || state==state.Float || state==state.FloatE || state==state.False || state==state.True || state==state.Quote || state==state.LParen) {
				Exp exp = exp();
				getToken();
				ExpList expList = expList();
				return MultipleExpList(exp, expList);
			}
			else
				errorMsg(5);
		}
		else if (t=="") {
			return new Explist();
		}
	}
		
	
	
	public static void errorMsg(int i)
	{
		errorFound = true;
		
		display(t + " : Syntax Error, unexpected symbol where");

		switch( i )
		{
		case 1:	displayln(" arith op or ) expected"); return;
		case 2: displayln(" id, int, float, true or false"); return;
		case 3:	displayln(" = expected"); return;
		case 4:	displayln(" ; expected"); return;
		case 5:	displayln(" id expected"); return;		
		}
	}

	public static void main(String argv[])
	{
		// argv[0]: input file containing an assignment list
		// argv[1]: output file displaying the parse tree
		
		setIO( argv[0], argv[1] );
		setLex();

		getToken();

		AssignmentList assignmentList = assignmentList(); // build a parse tree
		if ( ! t.isEmpty() )
			errorMsg(5);
		else if ( ! errorFound )
			assignmentList.printParseTree(""); // print the parse tree in linearly indented form in argv[1] file

		closeIO();
	}
}