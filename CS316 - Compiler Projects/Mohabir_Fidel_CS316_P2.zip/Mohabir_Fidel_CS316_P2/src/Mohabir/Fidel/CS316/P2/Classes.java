package Mohabir.Fidel.CS316.P2;
import java.util.*;

public class Classes {
}

abstract class Val
{
	abstract Val cloneVal();
	abstract float floatVal(); // conversion of integer value to float value
	abstract boolean isZero();
}

class IntVal extends Val
{
	int val;

	IntVal(int i)
	{
		val = i;
	}

	public String toString()
	{
		return val+"";
	}

	Val cloneVal()
	{
		return new IntVal(val);
	}

	float floatVal()
	{
		return (float)val;
	}
	
	boolean isZero()
	{
		return val == 0;
	}
}

class FloatVal extends Val
{
	float val;

	FloatVal(float f)
	{
		val = f;
	}

	public String toString()
	{
		return val+"";
	}

	Val cloneVal()
	{
		return new FloatVal(val);
	}

	float floatVal()
	{
		return val;
	}
	
	boolean isZero()
	{
		return val == 0.0f;
	}
}

abstract class FunDefList { //FunDefList
	abstract void printParseTree(String indent);
}

class FunDef extends FunDefList { //FunDef

	FunDef() {
		
	}
	@Override
	void printParseTree(String indent) {
		// TODO Auto-generated method stub
		
	}
	
}

class MultipleFunDef extends FunDefList { //MultipleFunDef
	FunDef funDef;
	FunDefList funDefList;
	
	
	void printParseTree(String indent) {
		
	}
}

abstract class ParameterList { //ParameterList
	abstract void printParseTree(String indent);
	
	ParameterList() {
		
	}
}

class NonEmptyParameterList extends ParameterList { //NonEmptyParameterList
	Id id;
	ParameterList parameterList;
	
	NonEmptyParameterList(Id ident, ParameterList parameter) {
		id = ident;
		parameterList = parameter;
	}
	
	void printParseTree(String indent) {
		
	}
	
}


abstract class ExpList {
	
}

class Exp extends ExpList {
	
}

class Header extends ParameterList{
	Id id;
	ParameterList parameterList;
	
	Header() {
		
	}
	@Override
	void printParseTree(String indent) {
		// TODO Auto-generated method stub
		
	}
}

abstract class SExp {
	SExp() {
		
	}
}
abstract class AtomSExp extends SExp{
	
}

abstract class Atom extends AtomSExp
{
	abstract void printParseTree(String indent);
	abstract Val Eval(HashMap<String,Val> state);
	abstract void emitInstructions();
}

class Id extends Atom{
	String id;
	
	Id(String ident) {
		id = ident;
	}
	

	void printParseTree(String indent)
	{
		IO.displayln(indent + indent.length() + " <atom> " + id);
	}
	
	Val Eval(HashMap<String,Val> state)
	{
		Val idVal = state.get(id);
		if ( idVal != null )
			return idVal.cloneVal();
		else
		{
			System.out.println( "variable "+id+" does not have a value" );
			return null;
		}
	}

	void emitInstructions()
	{
		IO.displayln("push " + id);
	}
}

class Int extends Atom
{
	int val;

	Int(int i)
	{
		val = i;
	}

	void printParseTree(String indent)
	{
		IO.displayln(indent + indent.length() + " <atom> " + val);
	}

	Val Eval(HashMap<String,Val> state)
	{
		return new IntVal(val);
	}
	
	void emitInstructions()
	{
		IO.displayln("push " + val);
	}
}

class Floatp extends Atom
{
	float val;

	Floatp(float f)
	{
		val = f;
	}

	void printParseTree(String indent)
	{
		IO.displayln(indent + indent.length() + " <atom> " + val);
	}

	Val Eval(HashMap<String,Val> state)
	{
		return new FloatVal(val);
	}
	
	void emitInstructions()
	{
		IO.displayln("push " + val);
	}
}

class TF extends Atom {
	String bool;
	
	TF(String t) {
		bool = t;
	}
	@Override
	void printParseTree(String indent) {
		IO.displayln(indent + indent.length() + " <atom> " + bool);
	}

	@Override
	Val Eval(HashMap<String, Val> state) {
		Val idVal = state.get(bool);
		if ( idVal != null )
			return idVal.cloneVal();
		else
		{
			System.out.println( "variable "+bool+" does not have a value" );
			return null;
		}
	}

	@Override
	void emitInstructions() {
		IO.displayln("push " + bool);	
	}
	
}

abstract class ListExp {
	
}

class ListExpInside extends ListExp{
	
}

class If extends Exp{
	
}

abstract class Case extends Exp{
	
}

class ElseCase extends Exp {
	
}

class CaseExp extends Case{
	
}

class CaseList extends CaseExp{
	
}


class conds extends CaseList {
	
}

class FunName extends ExpList {
	FunName
}

class OperatorExp extends ExpList {
	
}

